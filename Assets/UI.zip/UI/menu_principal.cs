using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;


public class menu_principal : MonoBehaviour
{

    UIDocument menu;

    

    [SerializeField] GameObject CamaraJuego;
    [SerializeField] GameObject CamaraMenu;




    //MenuPrincipal

    VisualElement MenuPrincipal;

    Button Start;



    //MenuJuego

    Button SalirJuego;

    Button Arboles;
    Button Plantas;
    Button Elementos;


    private void OnEnable()
    {
        menu = GetComponent<UIDocument>();
        VisualElement root = menu.rootVisualElement;

        MenuPrincipal = root.Q<VisualElement>("izq");

        Start = root.Q<Button>("start");


        //juego

        SalirJuego = root.Q<Button>("salir-button");
        Arboles = root.Q<Button>("arboles");
        Plantas = root.Q<Button>("plantas");
        Elementos = root.Q<Button>("elementos");


        //CallBacks

        Start.RegisterCallback<ClickEvent>(abrirJuego);

        SalirJuego.RegisterCallback<ClickEvent>(cerrarJuego);


    }


    private void abrirJuego(ClickEvent evt)
    {
        MenuPrincipal.AddToClassList("izq-desactivar");

        SalirJuego.AddToClassList("salir-button-active");
        Arboles.AddToClassList("submenu-button-active");
        Plantas.AddToClassList("submenu-button-active");
        Elementos.AddToClassList("submenu-button-active");

        CamaraJuego.SetActive(true);
        CamaraMenu.SetActive(false);
    }


    private void cerrarJuego(ClickEvent evt)
    {
        MenuPrincipal.RemoveFromClassList("izq-desactivar");


        SalirJuego.RemoveFromClassList("salir-button-active");
        Arboles.RemoveFromClassList("submenu-button-active");
        Plantas.RemoveFromClassList("submenu-button-active");
        Elementos.RemoveFromClassList("submenu-button-active");
    }
}
